/* Felicity Media · editor del sito (solo per chi è entrato in WordPress come amministratore).
   Clic su un testo → si riscrive sulla pagina → Invio o "Salva". Elenchi e team: + e ✕ al passaggio del mouse.
   "Pagina": titolo e descrizione per Google, immagine di condivisione, cronologia delle modifiche. */
(() => {
  "use strict";
  const C = window.FM_EDIT;
  if (!C) return;
  const root = document.documentElement;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  const TARGET = "[data-fe],[data-fe-li],[data-fe-team]";

  /* ---------- server ---------- */
  const api = async (path, body, method = "POST") => {
    const r = await fetch(C.rest + path, {
      method, credentials: "same-origin",
      headers: { "Content-Type": "application/json", "X-WP-Nonce": C.nonce },
      body: body ? JSON.stringify(body) : undefined
    });
    let j = {};
    try { j = await r.json(); } catch (e) { /* empty */ }
    if (!r.ok) throw new Error(j.message || (r.status === 403 ? "La sessione è scaduta: ricarica la pagina ed entra di nuovo in WordPress." : "Non è stato salvato (errore " + r.status + ")."));
    return j;
  };
  const save = (tipo, chiave, valore) => api("modifica", { tipo, chiave, valore });

  /* ---------- messages ---------- */
  const toastBox = h("div", "fe-toasts");
  const toast = (msg, kind = "") => {
    const t = h("div", "fe-toast " + kind, msg);
    toastBox.append(t);
    setTimeout(() => t.classList.add("is-out"), kind === "is-err" || kind === "is-warn" ? 9000 : 3200);
    setTimeout(() => t.remove(), kind === "is-err" || kind === "is-warn" ? 9600 : 3800);
  };
  const saved = (res, what = "Salvato") => {
    if (res && res.cache && !res.cache.ok) toast(`${what}. Tu lo vedi già; per i visitatori premi <b>Svuota la cache</b> su <a href="${C.cache}" target="_blank" rel="noopener">Register</a>.`, "is-warn");
    else toast(`${what}. È online per tutti.`, "is-ok");
  };

  /* ---------- the bar ---------- */
  const bar = h("div", "fe-bar");
  bar.innerHTML = `
    <button type="button" class="fe-btn fe-toggle" data-act="toggle"><span class="fe-dot"></span><span class="fe-toggle__t">Modifica il sito</span></button>
    <span class="fe-hint">Clicca su un testo per cambiarlo</span>
    <button type="button" class="fe-btn" data-act="page">Pagina</button>
    <button type="button" class="fe-btn" data-act="history">Cronologia</button>`;
  document.body.append(bar, toastBox);
  let on = false;
  const setOn = v => {
    on = v;
    root.classList.toggle("fe-on", v);
    $(".fe-toggle__t", bar).textContent = v ? "Fine modifiche" : "Modifica il sito";
    try { localStorage.setItem("fe-on", v ? "1" : "0"); } catch (e) { /* private mode */ }
    if (!v) { finish(false); hideRowCtl(); setHov(null); }
  };
  bar.addEventListener("click", e => {
    const b = e.target.closest("[data-act]");
    if (!b) return;
    const act = b.dataset.act;
    if (act === "toggle") setOn(!on);
    if (act === "page") openPage();
    if (act === "history") openHistory();
  });
  try { if (localStorage.getItem("fe-on") === "1") setOn(true); } catch (e) { /* private mode */ }

  /* ---------- what an element holds ---------- */
  const listOf = el => el.closest("[data-fe-list]");
  const raw = el => {
    if (el.dataset.fe) return C.t[el.dataset.fe] ?? el.innerHTML;
    if (el.dataset.feLi != null) return (C.l[listOf(el).dataset.feList] || [])[+el.dataset.feLi] ?? el.innerHTML;
    const [i, f] = el.dataset.feTeam.split(":");
    return esc((C.team[+i] || {})[f] ?? el.textContent);
  };
  const plainText = html => { const d = h("div", "", html); return d.textContent; };

  // what contenteditable leaves behind → the few tags the site uses
  const KEEP = { B: 1, STRONG: 1, EM: 1, I: 1, U: 1, SMALL: 1, SUP: 1, SUB: 1, BR: 1, A: 1 };
  const cleanHtml = node => {
    let out = "";
    node.childNodes.forEach(n => {
      if (n.nodeType === 3) { out += esc(n.textContent).replace(/ /g, "&nbsp;"); return; }
      if (n.nodeType !== 1) return;
      const tag = n.tagName;
      if (tag === "DIV" || tag === "P") { out += (out && !out.endsWith("<br>") ? "<br>" : "") + cleanHtml(n); return; }
      if (!KEEP[tag]) { out += cleanHtml(n); return; }
      if (tag === "BR") { out += "<br>"; return; }
      const t = tag.toLowerCase();
      if (t === "a") {
        const at = ["href", "target", "rel"].filter(a => n.getAttribute(a)).map(a => ` ${a}="${esc(n.getAttribute(a))}"`).join("");
        out += `<a${at}>${cleanHtml(n)}</a>`;
      } else {
        // a bold made by the browser as <b style> or <span style="font-weight"> keeps only the tag
        out += `<${t}>${cleanHtml(n)}</${t}>`;
      }
    });
    return out;
  };
  const tidy = s => s.replace(/^(\s|<br>|&nbsp;)+|(\s|<br>|&nbsp;)+$/g, "").replace(/(<br>\s*){3,}/g, "<br><br>");

  /* ---------- inline editing ---------- */
  const tools = h("div", "fe-tools");
  tools.innerHTML = `
    <button type="button" class="fe-tb" data-t="bold" title="Grassetto (⌘B)"><b>G</b></button>
    <button type="button" class="fe-tb" data-t="br" title="A capo (Maiusc + Invio)">↵</button>
    <button type="button" class="fe-tb fe-tb--txt" data-t="orig" title="Rimetti il testo di prima del sito">Originale</button>
    <span class="fe-tools__sp"></span>
    <button type="button" class="fe-tb fe-tb--txt" data-t="cancel" title="Annulla (Esc)">Annulla</button>
    <button type="button" class="fe-tb fe-tb--save" data-t="save" title="Salva (Invio)">Salva</button>`;
  document.body.append(tools);
  let cur = null, before = "", startClean = "", busy = false;

  const place = () => {
    if (!cur) return;
    const r = cur.getBoundingClientRect(), tw = tools.offsetWidth, th = tools.offsetHeight;
    let top = r.top - th - 10;
    if (top < 8) top = r.bottom + 10;
    top = Math.max(8, Math.min(innerHeight - th - 8, top));
    const left = Math.max(8, Math.min(innerWidth - tw - 8, r.left));
    tools.style.transform = `translate(${left}px, ${top}px)`;
    rowCtlFor(cur);
  };
  const loop = () => { if (cur) { place(); requestAnimationFrame(loop); } };

  const start = async el => {
    if (busy || cur === el) return;
    if (cur) { await finish(false); if (cur) return; }
    // a text inside a button cannot take a caret in every browser: it gets a small box instead
    if (el.closest("button")) return editInBox(el);
    cur = el;
    lastRange = null;
    before = el.innerHTML;
    el.innerHTML = raw(el);
    startClean = el.dataset.feTeam ? esc(el.textContent.replace(/\s+/g, " ").trim()) : tidy(cleanHtml(el));
    el.setAttribute("contenteditable", "true");
    el.spellcheck = true;
    el.classList.add("fe-editing");
    $('[data-t="orig"]', tools).hidden = !(el.dataset.fe && C.o[el.dataset.fe]);
    $('[data-t="bold"]', tools).hidden = $('[data-t="br"]', tools).hidden = !!el.dataset.feTeam;
    tools.classList.add("is-on");
    el.focus({ preventScroll: true });
    const sel = getSelection(), rg = document.createRange();
    rg.selectNodeContents(el); rg.collapse(false); sel.removeAllRanges(); sel.addRange(rg);
    requestAnimationFrame(loop);
  };
  function editInBox(el) {
    const b = h("div", "fe-form", `<label class="fe-field"><span>Testo</span><input type="text" maxlength="200"></label><div class="fe-row"><button type="button" class="fe-btn fe-btn--main" data-a="ok">Salva</button></div>`);
    const inp = $("input", b);
    inp.value = plainText(raw(el));
    const { close: closeM } = modal("Cambia il testo", b);
    const go = async () => {
      const html = esc(inp.value.trim());
      if (!html) { toast("Il testo non può essere vuoto.", "is-err"); return; }
      try { const res = await save("testo", el.dataset.fe, html); C.t[el.dataset.fe] = res.valore; C.o[el.dataset.fe] = true; el.innerHTML = res.valore; closeM(); saved(res); }
      catch (err) { toast(err.message, "is-err"); }
    };
    $("[data-a=ok]", b).addEventListener("click", go);
    inp.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); go(); } });
    setTimeout(() => inp.focus(), 30);
  }

  const close = html => {
    const el = cur;
    el.removeAttribute("contenteditable");
    el.classList.remove("fe-editing");
    el.innerHTML = html;
    cur = null;
    tools.classList.remove("is-on");
    if (window.ScrollTrigger) window.ScrollTrigger.refresh();
  };

  // finish(true) throws the change away, finish(false) saves it if something changed
  async function finish(cancel) {
    if (!cur || busy) return;
    const el = cur;
    if (cancel === true) { close(before); return; }
    const html = tidy(el.dataset.feTeam ? esc(el.innerText.replace(/\s+/g, " ").trim()) : cleanHtml(el));
    if (html === startClean) { close(before); return; }
    if (!plainText(html).trim() && !confirm("Il testo è vuoto: sulla pagina non si vedrà niente. Salvare lo stesso?")) return;
    busy = true; el.classList.add("is-busy");
    try {
      let res;
      if (el.dataset.fe) {
        res = await save("testo", el.dataset.fe, html);
        C.t[el.dataset.fe] = res.valore; C.o[el.dataset.fe] = true;
        close(res.valore);
      } else if (el.dataset.feLi != null) {
        const k = listOf(el).dataset.feList, items = [...C.l[k]];
        items[+el.dataset.feLi] = html;
        res = await save("lista", k, items);
        C.l[k] = res.valore; close(res.valore[+el.dataset.feLi] ?? html);
      } else {
        const [i, f] = el.dataset.feTeam.split(":"), team = C.team.map(p => ({ ...p }));
        team[+i][f] = plainText(html);
        res = await save("team", "", team);
        C.team = res.valore; close(esc((C.team[+i] || {})[f] || ""));
        syncTeam();
      }
      saved(res);
    } catch (err) {
      toast(err.message, "is-err");
    } finally {
      busy = false; el.classList.remove("is-busy");
    }
  }

  // the caret must stay where it was when a button of the small bar is pressed
  let lastRange = null;
  document.addEventListener("selectionchange", () => {
    const sel = getSelection();
    if (cur && sel.rangeCount && cur.contains(sel.getRangeAt(0).commonAncestorContainer)) lastRange = sel.getRangeAt(0).cloneRange();
  });
  const refocus = () => {
    if (!cur) return;
    if (document.activeElement !== cur) cur.focus({ preventScroll: true });
    if (lastRange && cur.contains(lastRange.commonAncestorContainer)) { const sel = getSelection(); sel.removeAllRanges(); sel.addRange(lastRange); }
  };
  tools.addEventListener("mousedown", e => e.preventDefault());
  tools.addEventListener("click", async e => {
    const b = e.target.closest("[data-t]");
    if (!b || !cur) return;
    const t = b.dataset.t;
    if (t === "bold" || t === "br") refocus();
    if (t === "bold") document.execCommand("bold");
    if (t === "br") document.execCommand("insertLineBreak");
    if (t === "bold" || t === "br") { const sel = getSelection(); if (sel.rangeCount) lastRange = sel.getRangeAt(0).cloneRange(); refocus(); }
    if (t === "cancel") finish(true);
    if (t === "save") finish(false);
    if (t === "orig" && cur.dataset.fe) {
      const el = cur, k = el.dataset.fe;
      if (!confirm("Rimettere il testo com’era prima delle tue modifiche?")) return;
      busy = true;
      try { const res = await save("originale", k, ""); C.t[k] = res.valore; C.o[k] = false; busy = false; close(res.valore); saved(res, "Testo originale rimesso"); }
      catch (err) { busy = false; toast(err.message, "is-err"); }
    }
  });

  document.addEventListener("keydown", e => {
    if (!cur || !cur.contains(e.target)) return;
    // Home / End move the caret along the line: the page itself must not scroll while writing
    if (e.key === "Home" || e.key === "End") { e.preventDefault(); e.stopPropagation(); getSelection().modify(e.shiftKey ? "extend" : "move", e.key === "End" ? "forward" : "backward", "lineboundary"); return; }
    if (e.key === "PageUp" || e.key === "PageDown") { e.preventDefault(); e.stopPropagation(); return; }
    if (e.key === "Escape") { e.preventDefault(); finish(true); }
    else if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); finish(false); }
    else if (e.key === "Enter" && e.shiftKey) { e.preventDefault(); if (!cur.dataset.feTeam) document.execCommand("insertLineBreak"); }
    else if ((e.metaKey || e.ctrlKey) && /^[iu]$/i.test(e.key)) e.preventDefault();   // only bold, like the site
  }, true);
  document.addEventListener("paste", e => {
    if (!cur || !cur.contains(e.target)) return;
    e.preventDefault();
    const text = (e.clipboardData || window.clipboardData).getData("text/plain").replace(/\r/g, "");
    document.execCommand("insertText", false, cur.dataset.feTeam ? text.replace(/\s+/g, " ") : text);
  });
  document.addEventListener("drop", e => { if (cur && cur.contains(e.target)) e.preventDefault(); }, true);

  // which text is under the pointer: the smallest visible one. Many texts sit under transparent layers
  // or are hidden by the animations, so the browser's own target cannot be trusted.
  const visible = el => {
    for (let n = el, op = 1; n && n.nodeType === 1; n = n.parentElement) {
      const cs = getComputedStyle(n);
      if (cs.display === "none" || cs.visibility === "hidden") return false;
      op *= +cs.opacity;
      if (op < .08) return false;
      if (n.inert) return false;
    }
    return true;
  };
  const hit = (x, y) => {
    let best = null, area = Infinity;
    for (const el of $$(TARGET)) {
      if (el.closest(".fe-bar,.fe-modal")) continue;
      const r = el.getBoundingClientRect();
      if (x < r.left - 2 || x > r.right + 2 || y < r.top - 2 || y > r.bottom + 2 || !r.width || !r.height) continue;
      const a = r.width * r.height;
      if (a < area && visible(el)) { best = el; area = a; }
    }
    return best;
  };
  const ui = n => n.closest(".fe-bar,.fe-tools,.fe-rowctl,.fe-modal,.fe-toasts,.media-modal,.media-modal-backdrop,#iubenda-cs-banner,.iubenda-tp-btn");
  document.addEventListener("click", e => {
    if (!on || ui(e.target)) return;
    if (cur && cur.contains(e.target)) { if (e.target.closest("a")) e.preventDefault(); e.stopPropagation(); return; }
    const el = hit(e.clientX, e.clientY);
    if (el) { e.preventDefault(); e.stopPropagation(); start(el); return; }
    if (cur) finish(false);
  }, true);
  ["pointerdown", "mousedown"].forEach(ev => document.addEventListener(ev, e => {
    if (!on || ui(e.target) || (cur && cur.contains(e.target))) return;
    if (hit(e.clientX, e.clientY)) e.stopPropagation();
  }, true));
  // the text under the pointer is shown
  let hov = null;
  const setHov = el => { if (el === hov) return; if (hov) hov.classList.toggle("fe-hover", false); hov = el; if (hov) hov.classList.toggle("fe-hover", true); };
  document.addEventListener("mousemove", e => { if (!on || cur || ui(e.target)) return setHov(null); setHov(hit(e.clientX, e.clientY)); }, { passive: true });
  addEventListener("beforeunload", e => {
    if (cur && (cur.dataset.feTeam ? esc(cur.innerText.replace(/\s+/g, " ").trim()) : tidy(cleanHtml(cur))) !== startClean) { e.preventDefault(); e.returnValue = ""; }
  });

  /* ---------- lists and team: add, remove, move ---------- */
  const rowCtl = h("div", "fe-rowctl");
  document.body.append(rowCtl);
  let row = null;
  const hideRowCtl = () => { rowCtl.classList.remove("is-on"); row = null; };
  const rowOf = n => n && n.closest("[data-fe-list] > li, [data-fe-teamlist] > [data-fe-row]");
  function rowCtlFor(n) {
    const r = rowOf(n);
    if (!on || !r) { if (!rowCtl.matches(":hover")) hideRowCtl(); return; }
    if (r !== row) {
      row = r;
      const team = !!r.dataset.feRow;
      rowCtl.innerHTML = (team ? `<button type="button" data-r="up" title="Sposta su">↑</button><button type="button" data-r="down" title="Sposta giù">↓</button>` : "")
        + `<button type="button" data-r="add" title="${team ? "Aggiungi una persona sotto" : "Aggiungi una voce sotto"}">+ ${team ? "Persona" : "Voce"}</button>`
        + `<button type="button" data-r="del" title="Elimina">✕</button>`;
    }
    rowCtl.classList.add("is-on");   // visible first: its size is needed to keep it on screen
    const b = r.getBoundingClientRect(), w = rowCtl.offsetWidth, hh = rowCtl.offsetHeight;
    const x = Math.max(8, Math.min(innerWidth - w - 8, b.right + 8));
    const y = Math.max(8, Math.min(innerHeight - hh - 8, b.top + b.height / 2 - hh / 2));
    rowCtl.style.transform = `translate(${x}px, ${y}px)`;
  }
  document.addEventListener("mousemove", e => { if (on && !cur && !ui(e.target)) rowCtlFor(hit(e.clientX, e.clientY) || e.target); }, { passive: true });
  addEventListener("scroll", () => { if (row && !cur) rowCtlFor(row); }, { passive: true });
  rowCtl.addEventListener("mousedown", e => e.preventDefault());
  rowCtl.addEventListener("click", async e => {
    const b = e.target.closest("[data-r]");
    if (!b || !row || busy) return;
    const act = b.dataset.r;
    if (cur) await finish(false);
    try {
      busy = true;
      if (row.dataset.feRow != null) {
        const team = C.team.map(p => ({ ...p })), i = +row.dataset.feRow;
        if (act === "del" && !confirm(`Togliere ${team[i].nome} dal team? (Home, Chi siamo e dati per Google)`)) { busy = false; return; }
        if (act === "add") team.splice(i + 1, 0, { nome: "Nome Cognome", ruolo: "Ruolo" });
        if (act === "del") team.splice(i, 1);
        if (act === "up" && i > 0) [team[i - 1], team[i]] = [team[i], team[i - 1]];
        if (act === "down" && i < team.length - 1) [team[i + 1], team[i]] = [team[i], team[i + 1]];
        const res = await save("team", "", team);
        reloadWith(res, act === "add" ? "Persona aggiunta: clicca su “Nome Cognome” e “Ruolo” per scriverli" : "Team aggiornato");
      } else {
        const k = listOf(row).dataset.feList, items = [...C.l[k]], i = +row.dataset.feLi;
        if (act === "del" && items.length === 1) { busy = false; toast("Un elenco deve avere almeno una voce.", "is-err"); return; }
        if (act === "del" && !confirm("Eliminare questa voce?")) { busy = false; return; }
        if (act === "add") items.splice(i + 1, 0, "Nuova voce");
        if (act === "del") items.splice(i, 1);
        const res = await save("lista", k, items);
        reloadWith(res, act === "add" ? "Voce aggiunta: clicca su “Nuova voce” per scriverla" : "Elenco aggiornato");
      }
    } catch (err) { busy = false; toast(err.message, "is-err"); }
  });
  // the page is rebuilt by WordPress: reload, keep the scroll and say what happened
  const reloadWith = (res, msg) => {
    try { sessionStorage.setItem("fe-after", JSON.stringify({ y: scrollY, msg, warn: res.cache && !res.cache.ok })); } catch (e) { /* private mode */ }
    location.reload();
  };
  try {
    const a = JSON.parse(sessionStorage.getItem("fe-after") || "null");
    if (a) {
      sessionStorage.removeItem("fe-after");
      addEventListener("load", () => setTimeout(() => {
        scrollTo(0, a.y);
        if (window.__fm && window.__fm.lenis) window.__fm.lenis.scrollTo(a.y, { immediate: true });
        saved({ cache: { ok: !a.warn } }, a.msg);
      }, 400));
    }
  } catch (e) { /* private mode */ }
  // the same person appears twice on the home only once; keep any other copy on this page in step
  const syncTeam = () => $$("[data-fe-team]").forEach(n => {
    if (n === cur) return;
    const [i, f] = n.dataset.feTeam.split(":");
    if (C.team[+i]) n.textContent = C.team[+i][f];
  });

  /* ---------- panels ---------- */
  const modal = (title, body) => {
    const m = h("div", "fe-modal");
    m.innerHTML = `<div class="fe-modal__box" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="fe-modal__head"><h2>${esc(title)}</h2><button type="button" class="fe-x" data-close aria-label="Chiudi">✕</button></div><div class="fe-modal__body"></div></div>`;
    $(".fe-modal__body", m).append(body);
    const closeM = () => { m.remove(); document.removeEventListener("keydown", onKey, true); };
    const onKey = e => { if (e.key === "Escape" && !document.querySelector(".media-modal:not([style*='none'])")) { e.stopPropagation(); closeM(); } };
    m.addEventListener("click", e => { if (e.target === m || e.target.closest("[data-close]")) closeM(); });
    document.addEventListener("keydown", onKey, true);
    document.body.append(m);
    if (window.__fm && window.__fm.lenis) window.__fm.lenis.stop?.();
    const obs = new MutationObserver(() => { if (!m.isConnected) { obs.disconnect(); if (window.__fm && window.__fm.lenis) window.__fm.lenis.start?.(); } });
    obs.observe(document.body, { childList: true });
    return { m, close: closeM };
  };

  function openPage() {
    const b = h("div", "fe-form");
    const seo = C.seo;
    b.innerHTML = (seo ? `
      <p class="fe-note">Come appare questa pagina su Google. Il titolo resta sotto i 60 caratteri, la descrizione sotto i 160.</p>
      <label class="fe-field"><span>Titolo su Google <i data-n="t"></i></span><input type="text" name="title" maxlength="120" value="${esc(seo.now.title)}"></label>
      <label class="fe-field"><span>Descrizione su Google <i data-n="d"></i></span><textarea name="desc" rows="3" maxlength="320">${esc(seo.now.desc)}</textarea></label>
      <div class="fe-serp"><span class="fe-serp__u">felicitymedia.it</span><span class="fe-serp__t"></span><span class="fe-serp__d"></span></div>
      <div class="fe-row"><button type="button" class="fe-btn fe-btn--main" data-a="seo">Salva titolo e descrizione</button><button type="button" class="fe-btn" data-a="seo-orig">Rimetti quelli originali</button></div>
      <hr>` : `<p class="fe-note">Questa pagina non compare su Google.</p><hr>`) + `
      <p class="fe-label">Immagine di condivisione</p>
      <p class="fe-note">L’anteprima che compare quando qualcuno manda il link del sito su WhatsApp, Facebook o LinkedIn. Misura ideale 1200 × 630.</p>
      <div class="fe-og"><img alt="" src="${esc(C.og.now || C.og.orig)}"></div>
      <div class="fe-row"><button type="button" class="fe-btn fe-btn--main" data-a="og">Cambia immagine</button><button type="button" class="fe-btn" data-a="og-orig" ${C.og.now ? "" : "hidden"}>Rimetti quella originale</button></div>`;
    const { close: closeM } = modal("Pagina", b);
    const T = $("[name=title]", b), D = $("[name=desc]", b);
    const upd = () => {
      if (!T) return;
      $("[data-n=t]", b).textContent = `${T.value.length}/60`; $("[data-n=t]", b).classList.toggle("is-over", T.value.length > 60);
      $("[data-n=d]", b).textContent = `${D.value.length}/160`; $("[data-n=d]", b).classList.toggle("is-over", D.value.length > 160);
      $(".fe-serp__t", b).textContent = T.value; $(".fe-serp__d", b).textContent = D.value;
    };
    T && [T, D].forEach(i => i.addEventListener("input", upd)); upd();
    b.addEventListener("click", async e => {
      const a = e.target.closest("[data-a]");
      if (!a) return;
      try {
        if (a.dataset.a === "seo" || a.dataset.a === "seo-orig") {
          const v = a.dataset.a === "seo" ? { title: T.value, desc: D.value } : seo.orig;
          const res = await save("seo", C.view, v);
          C.seo.now = res.valore; T.value = res.valore.title; D.value = res.valore.desc; upd();
          document.title = res.valore.title;
          saved(res, "Titolo e descrizione salvati");
        }
        if (a.dataset.a === "og") pickImage(async id => {
          const res = await save("og", "", id);
          C.og.now = res.valore; $(".fe-og img", b).src = res.valore; $("[data-a=og-orig]", b).hidden = false;
          saved(res, "Immagine di condivisione cambiata");
        });
        if (a.dataset.a === "og-orig") {
          const res = await save("og", "", 0);
          C.og.now = ""; $(".fe-og img", b).src = C.og.orig; a.hidden = true;
          saved(res, "Immagine originale rimessa");
        }
      } catch (err) { toast(err.message, "is-err"); }
    });
    return closeM;
  }

  // WordPress's own media library: upload or choose
  function pickImage(done) {
    if (!window.wp || !wp.media) { toast("La libreria delle immagini non si è caricata: ricarica la pagina.", "is-err"); return; }
    const frame = wp.media({ title: "Scegli un’immagine", button: { text: "Usa questa immagine" }, library: { type: "image" }, multiple: false });
    frame.on("select", () => {
      const a = frame.state().get("selection").first().toJSON();
      if (a.width && a.width < 600) toast("Questa immagine è piccola: sui social potrebbe vedersi sgranata.", "is-warn");
      Promise.resolve(done(a.id)).catch(err => toast(err.message, "is-err"));
    });
    frame.open();
  }

  async function openHistory() {
    const b = h("div", "fe-form", `<p class="fe-note">Le ultime modifiche, dalla più recente. “Torna a prima” annulla quella modifica e tutte quelle fatte dopo.</p><ol class="fe-hist"><li class="fe-note">Carico…</li></ol>`);
    modal("Cronologia", b);
    try {
      const list = await api("storia", null, "GET");
      $(".fe-hist", b).innerHTML = list.length ? list.map(x => `<li><div><b>${esc(x.label)}</b><span>${esc(x.when)}${x.who ? " · " + esc(x.who) : ""}</span></div><button type="button" class="fe-btn" data-i="${x.i}">Torna a prima</button></li>`).join("") : `<li class="fe-note">Ancora nessuna modifica.</li>`;
    } catch (err) { $(".fe-hist", b).innerHTML = `<li class="fe-note">${esc(err.message)}</li>`; }
    b.addEventListener("click", async e => {
      const x = e.target.closest("[data-i]");
      if (!x) return;
      if (!confirm("Tornare a prima di questa modifica? Si annullano anche tutte quelle fatte dopo.")) return;
      try { const res = await api("ripristina", { i: +x.dataset.i }); reloadWith(res, "Versione ripristinata"); }
      catch (err) { toast(err.message, "is-err"); }
    });
  }
})();
