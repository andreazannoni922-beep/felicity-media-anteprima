<?php
/**
 * The editor: whoever can manage the site opens it, clicks on a text and rewrites it.
 * Texts, simple lists, the team, the titles for Google and the share image are saved in one option
 * (fm_modifiche); views/fe.json keeps the originals. Every save keeps the previous version (fm_modifiche_storia)
 * and asks Register's cache to forget the pages, so visitors see the change at once.
 */
defined( 'ABSPATH' ) || exit;

const FM_OPT  = 'fm_modifiche';
const FM_HIST = 'fm_modifiche_storia';
const FM_TAGS = array(
	'b'      => array(),
	'strong' => array(),
	'em'     => array(),
	'i'      => array(),
	'u'      => array(),
	'small'  => array(),
	'sup'    => array(),
	'sub'    => array(),
	'br'     => array(),
	'a'      => array( 'href' => true, 'target' => true, 'rel' => true ),
);

function fm_can_edit() {
	return is_user_logged_in() && current_user_can( 'edit_theme_options' );
}

function fm_defaults() {
	static $d = null;
	if ( null === $d ) {
		$f = get_template_directory() . '/views/fe.json';
		$d = file_exists( $f ) ? json_decode( file_get_contents( $f ), true ) : array();
		$d = is_array( $d ) ? $d : array();
		$d += array( 't' => array(), 'h' => array(), 'l' => array(), 'seo' => array(), 'team' => array(), 'tpl' => array(), 'og' => '', 'ldHead' => null );
	}
	return $d;
}

function fm_saved() {
	$s = get_option( FM_OPT, array() );
	$s = is_array( $s ) ? $s : array();
	return $s + array( 't' => array(), 'l' => array(), 'seo' => array() );
}

// The theme's own addresses inside the originals ({{H}}, {{T}}) become real ones for the editor.
function fm_tokens( $s ) {
	return strtr( $s, array( '{{T}}' => get_template_directory_uri(), '{{H}}' => untrailingslashit( home_url() ) ) );
}

function fm_text( $k ) {
	$s = fm_saved();
	$d = fm_defaults();
	return isset( $s['t'][ $k ] ) ? $s['t'][ $k ] : ( isset( $d['t'][ $k ] ) ? $d['t'][ $k ] : '' );
}
function fm_list( $k ) {
	$s = fm_saved();
	$d = fm_defaults();
	return isset( $s['l'][ $k ] ) ? $s['l'][ $k ] : ( isset( $d['l'][ $k ] ) ? $d['l'][ $k ] : array() );
}
function fm_team() {
	$s = fm_saved();
	return isset( $s['team'] ) && is_array( $s['team'] ) ? $s['team'] : fm_defaults()['team'];
}
function fm_seo( $view ) {
	$s = fm_saved();
	$d = fm_defaults();
	$o = isset( $d['seo'][ $view ] ) ? $d['seo'][ $view ] : array( 'title' => 'Felicity Media', 'desc' => '' );
	return isset( $s['seo'][ $view ] ) ? array_merge( $o, $s['seo'][ $view ] ) : $o;
}
function fm_og() {
	$s = fm_saved();
	return ! empty( $s['og'] ) ? $s['og'] : '';
}

// An email or phone written in a text: its link follows what is written.
function fm_href_from_text( $scheme, $html ) {
	$t = trim( html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES, 'UTF-8' ) );
	if ( 'mailto' === $scheme ) {
		return is_email( $t ) ? 'mailto:' . $t : null;
	}
	$n = preg_replace( '/[^\d+]/', '', $t );
	if ( strlen( preg_replace( '/\D/', '', $n ) ) < 6 ) {
		return null;
	}
	if ( 0 === strpos( $n, '00' ) ) {
		$n = '+' . substr( $n, 2 );
	} elseif ( '+' !== $n[0] ) {
		$n = '+39' . $n;
	}
	return 'tel:' . $n;
}

function fm_json( $v ) {
	return wp_json_encode( $v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG );
}

function fm_team_html( $which ) {
	$d   = fm_defaults();
	$tpl = isset( $d['tpl'][ $which ] ) ? $d['tpl'][ $which ] : null;
	if ( ! $tpl ) {
		return '';
	}
	$out = '';
	foreach ( array_values( fm_team() ) as $i => $p ) {
		$out .= $tpl['sep'] . strtr(
			$tpl['li'],
			array(
				'{i}'      => $i,
				'{active}' => ( 'crew' === $which && 0 === $i ) ? ' is-active' : '',
				'{nome}'   => esc_html( $p['nome'] ),
				'{ruolo}'  => esc_html( $p['ruolo'] ),
			)
		);
	}
	return $out . $tpl['end'];
}

// Fills the tokens of a theme page (views/*.html). Called by index.php before anything else.
function fm_render( $html, $view ) {
	$d    = fm_defaults();
	$s    = fm_saved();
	$seo  = fm_seo( $view );
	$keys = array( 't' => array(), 'l' => array(), 'team' => false );

	$html = preg_replace_callback(
		'/\{\{h:([\w-]+)\}\}/',
		function ( $m ) use ( $d, $s ) {
			$def = isset( $d['h'][ $m[1] ] ) ? $d['h'][ $m[1] ] : '#';
			if ( isset( $s['t'][ $m[1] ] ) ) {
				$h = fm_href_from_text( strtok( $def, ':' ), $s['t'][ $m[1] ] );
				return $h ? esc_attr( $h ) : $def;
			}
			return $def;
		},
		$html
	);
	$html = preg_replace_callback(
		'/\{\{t:([\w-]+)\}\}/',
		function ( $m ) use ( &$keys ) {
			$keys['t'][] = $m[1];
			return fm_text( $m[1] );
		},
		$html
	);
	$html = preg_replace_callback(
		'/\{\{l:([\w-]+)\}\}/',
		function ( $m ) use ( &$keys ) {
			$keys['l'][] = $m[1];
			$out         = '';
			foreach ( array_values( fm_list( $m[1] ) ) as $i => $v ) {
				$out .= '<li data-fe-li="' . $i . '">' . $v . '</li>';
			}
			return $out;
		},
		$html
	);
	$html = preg_replace_callback(
		'/\{\{team:(people|crew)\}\}/',
		function ( $m ) use ( &$keys ) {
			$keys['team'] = true;
			return fm_team_html( $m[1] );
		},
		$html
	);
	$members = array();
	if ( $d['ldHead'] ) {
		$members[] = $d['ldHead'];
	}
	foreach ( fm_team() as $p ) {
		$members[] = array( '@type' => 'Person', 'name' => $p['nome'], 'jobTitle' => $p['ruolo'] );
	}
	$og   = fm_og();
	$html = strtr(
		$html,
		array(
			'{{teamld}}' => fm_json( $members ),
			'{{st}}'     => esc_attr( $seo['title'] ),
			'{{sd}}'     => esc_attr( $seo['desc'] ),
			'{{stj}}'    => substr( fm_json( $seo['title'] ), 1, -1 ),
			'{{sdj}}'    => substr( fm_json( $seo['desc'] ), 1, -1 ),
			'{{og}}'     => $og ? esc_url( $og ) : $d['og'],
		)
	);
	$GLOBALS['fm_page'] = array( 'view' => $view, 'keys' => $keys );
	return $html;
}

/* ------------------------------------------------------------ saving */

function fm_clean_html( $html ) {
	$html = (string) $html;
	$html = preg_replace( '#<(div|p)[^>]*>#i', '<br>', $html );
	$html = preg_replace( '#</(div|p)>#i', '', $html );
	$html = wp_kses( $html, FM_TAGS );
	$html = preg_replace( '#^(\s|<br\s*/?>|&nbsp;)+|(\s|<br\s*/?>|&nbsp;)+$#i', '', $html );
	$html = preg_replace( '#(<br\s*/?>\s*){3,}#i', '<br><br>', $html );
	// the link of an email or phone follows its text
	$html = preg_replace_callback(
		'#<a([^>]*)href="(mailto|tel):[^"]*"([^>]*)>(.*?)</a>#is',
		function ( $m ) {
			$h = fm_href_from_text( $m[2], $m[4] );
			return $h ? '<a' . $m[1] . 'href="' . esc_attr( $h ) . '"' . $m[3] . '>' . $m[4] . '</a>' : $m[0];
		},
		$html
	);
	return trim( $html );
}

function fm_who() {
	$u = wp_get_current_user();
	return $u && $u->exists() ? $u->display_name : '';
}

function fm_store( $new, $label ) {
	$hist = get_option( FM_HIST, array() );
	$hist = is_array( $hist ) ? $hist : array();
	array_unshift( $hist, array( 'data' => fm_saved(), 'when' => time(), 'who' => fm_who(), 'label' => $label ) );
	update_option( FM_HIST, array_slice( $hist, 0, 40 ), false );
	update_option( FM_OPT, $new, true );
	return fm_purge();
}

// Register's cache (Varnish) keeps the pages until told otherwise: it accepts PURGE from the server itself.
function fm_purge() {
	$urls = array( home_url( '/' ) );
	foreach ( array( 'servizi', 'metodo', 'chi-siamo', 'contatti' ) as $slug ) {
		$urls[] = home_url( '/' . $slug . '/' );
	}
	$codes = array();
	// all pages at once: a save must not wait for five answers in a row
	if ( class_exists( '\WpOrg\Requests\Requests' ) ) {
		$reqs = array();
		foreach ( $urls as $u ) {
			$reqs[] = array( 'url' => $u, 'type' => 'PURGE', 'headers' => array(), 'data' => null );
		}
		try {
			$res = \WpOrg\Requests\Requests::request_multiple(
				$reqs,
				array( 'timeout' => 5, 'connect_timeout' => 3, 'follow_redirects' => false, 'verify' => ABSPATH . WPINC . '/certificates/ca-bundle.crt' )
			);
			foreach ( $res as $r ) {
				$codes[] = $r instanceof \WpOrg\Requests\Response ? (int) $r->status_code : 0;
			}
		} catch ( \Throwable $e ) {
			$codes = array();
		}
	}
	if ( ! $codes ) {
		foreach ( $urls as $u ) {
			$r       = wp_remote_request( $u, array( 'method' => 'PURGE', 'timeout' => 4, 'redirection' => 0 ) );
			$codes[] = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
		}
	}
	$ok = ! array_filter( $codes, function ( $c ) { return $c < 200 || $c >= 300; } );
	update_option( 'fm_purge_ultima', array( 'when' => time(), 'codes' => $codes ), false );
	return array( 'ok' => $ok, 'codes' => $codes );
}

function fm_short( $html ) {
	$t = trim( html_entity_decode( wp_strip_all_tags( str_replace( '<br>', ' ', $html ) ), ENT_QUOTES, 'UTF-8' ) );
	return mb_strlen( $t ) > 48 ? mb_substr( $t, 0, 46 ) . '…' : $t;
}

function fm_rest_save( WP_REST_Request $r ) {
	$d    = fm_defaults();
	$s    = fm_saved();
	$tipo = (string) $r->get_param( 'tipo' );
	$k    = (string) $r->get_param( 'chiave' );
	$v    = $r->get_param( 'valore' );
	$out  = array();

	switch ( $tipo ) {
		case 'testo':
			if ( ! isset( $d['t'][ $k ] ) ) {
				return new WP_Error( 'fm', 'Questo testo non esiste più: ricarica la pagina.', array( 'status' => 400 ) );
			}
			$html = fm_clean_html( $v );
			if ( mb_strlen( $html ) > 8000 ) {
				return new WP_Error( 'fm', 'Il testo è troppo lungo.', array( 'status' => 400 ) );
			}
			if ( fm_tokens( $d['t'][ $k ] ) === $html || $d['t'][ $k ] === $html ) {
				unset( $s['t'][ $k ] );
			} else {
				$s['t'][ $k ] = $html;
			}
			$label        = 'Testo: «' . fm_short( $html ) . '»';
			$out['valore'] = fm_tokens( fm_text_from( $s, $k ) );
			break;
		case 'originale':
			if ( ! isset( $d['t'][ $k ] ) ) {
				return new WP_Error( 'fm', 'Questo testo non esiste più: ricarica la pagina.', array( 'status' => 400 ) );
			}
			unset( $s['t'][ $k ] );
			$label         = 'Testo riportato all’originale: «' . fm_short( $d['t'][ $k ] ) . '»';
			$out['valore'] = fm_tokens( $d['t'][ $k ] );
			break;
		case 'lista':
			if ( ! isset( $d['l'][ $k ] ) || ! is_array( $v ) ) {
				return new WP_Error( 'fm', 'Questo elenco non esiste più: ricarica la pagina.', array( 'status' => 400 ) );
			}
			$items = array_values( array_filter( array_map( 'fm_clean_html', array_slice( $v, 0, 40 ) ), 'strlen' ) );
			if ( ! $items ) {
				return new WP_Error( 'fm', 'Un elenco deve avere almeno una voce.', array( 'status' => 400 ) );
			}
			if ( $items === $d['l'][ $k ] ) {
				unset( $s['l'][ $k ] );
			} else {
				$s['l'][ $k ] = $items;
			}
			$label         = 'Elenco: «' . fm_short( $items[0] ) . '…»';
			$out['valore'] = $items;
			break;
		case 'team':
			if ( ! is_array( $v ) ) {
				return new WP_Error( 'fm', 'Dati del team non validi.', array( 'status' => 400 ) );
			}
			$team = array();
			foreach ( array_slice( $v, 0, 40 ) as $p ) {
				$nome  = isset( $p['nome'] ) ? sanitize_text_field( $p['nome'] ) : '';
				$ruolo = isset( $p['ruolo'] ) ? sanitize_text_field( $p['ruolo'] ) : '';
				if ( '' !== $nome ) {
					$team[] = array( 'nome' => $nome, 'ruolo' => $ruolo );
				}
			}
			if ( $team === $d['team'] ) {
				unset( $s['team'] );
			} else {
				$s['team'] = $team;
			}
			$label         = 'Team (' . count( $team ) . ' persone)';
			$out['valore'] = $team;
			break;
		case 'seo':
			if ( ! isset( $d['seo'][ $k ] ) || ! is_array( $v ) ) {
				return new WP_Error( 'fm', 'Pagina sconosciuta.', array( 'status' => 400 ) );
			}
			$t = sanitize_text_field( isset( $v['title'] ) ? $v['title'] : '' );
			$e = sanitize_textarea_field( isset( $v['desc'] ) ? $v['desc'] : '' );
			$e = trim( preg_replace( '/\s+/', ' ', $e ) );
			if ( '' === $t ) {
				return new WP_Error( 'fm', 'Il titolo non può essere vuoto.', array( 'status' => 400 ) );
			}
			$o = $d['seo'][ $k ];
			if ( $t === $o['title'] && $e === $o['desc'] ) {
				unset( $s['seo'][ $k ] );
			} else {
				$s['seo'][ $k ] = array( 'title' => $t, 'desc' => $e );
			}
			$label         = 'Titolo e descrizione per Google (' . $k . ')';
			$out['valore'] = array( 'title' => $t, 'desc' => $e );
			break;
		case 'og':
			$id = (int) $v;
			if ( $id ) {
				$url = wp_get_attachment_image_url( $id, 'full' );
				if ( ! $url || ! wp_attachment_is_image( $id ) ) {
					return new WP_Error( 'fm', 'Scegli un’immagine.', array( 'status' => 400 ) );
				}
				$s['og'] = $url;
			} else {
				unset( $s['og'] );
			}
			$label         = 'Immagine di condivisione';
			$out['valore'] = $id ? $s['og'] : '';
			break;
		default:
			return new WP_Error( 'fm', 'Richiesta sconosciuta.', array( 'status' => 400 ) );
	}
	$out['cache'] = fm_store( $s, $label );
	$out['ok']    = true;
	return $out;
}
function fm_text_from( $s, $k ) {
	$d = fm_defaults();
	return isset( $s['t'][ $k ] ) ? $s['t'][ $k ] : $d['t'][ $k ];
}

function fm_rest_history() {
	$hist = get_option( FM_HIST, array() );
	$out  = array();
	foreach ( (array) $hist as $i => $h ) {
		$out[] = array(
			'i'     => $i,
			'when'  => wp_date( 'j M Y, H:i', $h['when'] ),
			'who'   => $h['who'],
			'label' => $h['label'],
		);
	}
	return $out;
}

function fm_rest_restore( WP_REST_Request $r ) {
	$hist = get_option( FM_HIST, array() );
	$i    = (int) $r->get_param( 'i' );
	if ( ! isset( $hist[ $i ] ) ) {
		return new WP_Error( 'fm', 'Versione non trovata.', array( 'status' => 404 ) );
	}
	// the state before change number i: everything done from then on is undone
	return array(
		'ok'    => true,
		'cache' => fm_store( $hist[ $i ]['data'], 'Tornato a prima di: ' . $hist[ $i ]['label'] ),
	);
}

add_action(
	'rest_api_init',
	function () {
		$can = 'fm_can_edit';
		register_rest_route( 'felicity/v1', '/modifica', array( 'methods' => 'POST', 'permission_callback' => $can, 'callback' => 'fm_rest_save' ) );
		register_rest_route( 'felicity/v1', '/storia', array( 'methods' => 'GET', 'permission_callback' => $can, 'callback' => 'fm_rest_history' ) );
		register_rest_route( 'felicity/v1', '/ripristina', array( 'methods' => 'POST', 'permission_callback' => $can, 'callback' => 'fm_rest_restore' ) );
		register_rest_route( 'felicity/v1', '/cache', array( 'methods' => 'POST', 'permission_callback' => $can, 'callback' => 'fm_purge' ) );
	}
);

/* ------------------------------------------------------------ the editor on the page */

function fm_editor_files() {
	$f = get_template_directory() . '/views/editor.json';
	return file_exists( $f ) ? json_decode( file_get_contents( $f ), true ) : null;
}

add_action(
	'wp_enqueue_scripts',
	function () {
		if ( ! fm_can_edit() || ! ( $f = fm_editor_files() ) ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'fm-editor', get_template_directory_uri() . '/assets/editor/' . $f['css'], array(), null );
		wp_enqueue_script( 'fm-editor', get_template_directory_uri() . '/assets/editor/' . $f['js'], array( 'media-editor' ), null, true );
	},
	200
);

add_action(
	'wp_footer',
	function () {
		if ( ! fm_can_edit() || empty( $GLOBALS['fm_page'] ) ) {
			return;
		}
		$p   = $GLOBALS['fm_page'];
		$d   = fm_defaults();
		$s   = fm_saved();
		$cfg = array(
			'rest'  => esc_url_raw( rest_url( 'felicity/v1/' ) ),
			'nonce' => wp_create_nonce( 'wp_rest' ),
			'view'  => $p['view'],
			'who'   => fm_who(),
			't'     => array(),
			'o'     => array(),
			'l'     => array(),
			'team'  => fm_team(),
			'seo'   => isset( $d['seo'][ $p['view'] ] ) ? array( 'now' => fm_seo( $p['view'] ), 'orig' => $d['seo'][ $p['view'] ] ) : null,
			'og'    => array( 'now' => fm_og(), 'orig' => fm_tokens( $d['og'] ) ),
			'cache' => 'https://wlcp.register.it/it/cms/felid7/settings',
			'admin' => admin_url(),
		);
		foreach ( array_unique( $p['keys']['t'] ) as $k ) {
			$cfg['t'][ $k ] = fm_tokens( fm_text( $k ) );
			$cfg['o'][ $k ] = isset( $s['t'][ $k ] );
		}
		foreach ( array_unique( $p['keys']['l'] ) as $k ) {
			$cfg['l'][ $k ] = array_map( 'fm_tokens', fm_list( $k ) );
		}
		echo '<script>window.FM_EDIT=' . fm_json( $cfg ) . ';</script>' . "\n";
	},
	5
);
