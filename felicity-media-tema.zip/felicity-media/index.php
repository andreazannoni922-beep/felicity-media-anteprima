<?php
defined( 'ABSPATH' ) || exit;

$views = array( 'servizi', 'metodo', 'chi-siamo', 'contatti', 'privacy', 'cookie' );
if ( is_404() ) {
	$view = '404';
} elseif ( is_front_page() ) {
	$view = 'index';
} elseif ( is_page( $views ) ) {
	$view = get_post_field( 'post_name', get_queried_object_id() );
} else {
	// No blog on this site.
	wp_safe_redirect( home_url( '/' ) );
	exit;
}

ob_start();
wp_head();
$head = ob_get_clean();
ob_start();
wp_footer();
$foot = ob_get_clean();

// phpcs:ignore WordPress.Security.EscapeOutput -- the page is the theme's own file.
echo strtr(
	file_get_contents( get_template_directory() . '/views/' . $view . '.html' ),
	array(
		'{{T}}'       => get_template_directory_uri(),
		'{{H}}'       => untrailingslashit( home_url() ),
		'{{REST}}'    => esc_url_raw( rest_url( 'felicity/v1/contatto' ) ),
		'{{WP_HEAD}}' => $head,
		'{{WP_FOOT}}' => $foot,
	)
);
