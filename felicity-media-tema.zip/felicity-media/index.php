<?php
defined( 'ABSPATH' ) || exit;

$views = array( 'servizi', 'metodo', 'chi-siamo', 'contatti', 'privacy', 'cookie' );
if ( is_404() ) {
	$view = '404';
} elseif ( is_front_page() ) {
	$view = 'index';
} elseif ( is_page( $views ) ) {
	$view = get_post_field( 'post_name', get_queried_object_id() );
} else {
	// No blog on this site.
	wp_safe_redirect( home_url( '/' ) );
	exit;
}

// The legal texts live on iubenda when the site is linked to it.
$legal = get_template_directory() . '/views/legale.json';
if ( in_array( $view, array( 'privacy', 'cookie' ), true ) && file_exists( $legal ) ) {
	$urls = json_decode( file_get_contents( $legal ), true );
	add_filter( 'allowed_redirect_hosts', function ( $h ) { $h[] = 'www.iubenda.com'; return $h; } );
	wp_safe_redirect( $urls[ $view ], 302 );
	exit;
}

ob_start();
wp_head();
$head = ob_get_clean();
ob_start();
wp_footer();
$foot = ob_get_clean();

// phpcs:ignore WordPress.Security.EscapeOutput -- the page is the theme's own file.
echo strtr(
	file_get_contents( get_template_directory() . '/views/' . $view . '.html' ),
	array(
		'{{T}}'       => get_template_directory_uri(),
		'{{H}}'       => untrailingslashit( home_url() ),
		'{{REST}}'    => esc_url_raw( rest_url( 'felicity/v1/contatto' ) ),
		'{{WP_HEAD}}' => $head,
		'{{WP_FOOT}}' => $foot,
	)
);
