<?php
defined( 'ABSPATH' ) || exit;

const FM_MAIL = 'info@felicitymedia.it';

// The pages carry their own markup and assets: WordPress adds nothing to them.
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );
remove_action( 'wp_head', 'rest_output_link_wp_head' );
remove_action( 'wp_head', 'feed_links', 2 );
remove_action( 'wp_head', 'feed_links_extra', 3 );
remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
add_filter( 'show_admin_bar', '__return_false' );
add_action( 'wp_enqueue_scripts', function () {
	foreach ( array( 'wp-block-library', 'global-styles', 'classic-theme-styles' ) as $h ) {
		wp_dequeue_style( $h );
	}
}, 100 );

// sitemap, robots, llms and favicon come from the theme: the host's SEO plugin lists pages that do not exist.
add_action( 'after_setup_theme', 'fm_root_files', 0 );
function fm_root_files() {
	$path  = isset( $_SERVER['REQUEST_URI'] ) ? strtok( wp_unslash( $_SERVER['REQUEST_URI'] ), '?' ) : '';
	$dir   = get_template_directory();
	$files = array(
		'/sitemap.xml' => array( $dir . '/views/sitemap.xml', 'application/xml; charset=UTF-8' ),
		'/robots.txt'  => array( $dir . '/views/robots.txt', 'text/plain; charset=UTF-8' ),
		'/llms.txt'    => array( $dir . '/views/llms.txt', 'text/plain; charset=UTF-8' ),
		'/favicon.ico' => array( $dir . '/assets/favicon-48.png', 'image/png' ),
	);
	if ( isset( $files[ $path ] ) && file_exists( $files[ $path ][0] ) ) {
		status_header( 200 );
		header( 'Content-Type: ' . $files[ $path ][1] );
		readfile( $files[ $path ][0] );
		exit;
	}
}

// The name shown by search engines and browsers (the install was called "felicitymedia").
add_filter( 'pre_option_blogname', function () { return 'Felicity Media'; } );
add_filter( 'pre_option_blogdescription', function () { return 'Studio di comunicazione a Modena'; } );

// Full snippets for search engines and AI answers.
add_filter( 'wp_robots', function ( $robots ) {
	$robots['max-snippet']       = '-1';
	$robots['max-video-preview'] = '-1';
	return $robots;
} );

// No feeds and no author pages: the site has no blog, and the author address exposed the founder's mail.
add_action( 'template_redirect', function () {
	if ( is_feed() || is_author() || isset( $_GET['author'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		global $wp_query;
		$wp_query->set_404();
		status_header( 404 );
		nocache_headers();
	}
}, 1 );
add_filter( 'rest_endpoints', function ( $endpoints ) {
	if ( ! is_user_logged_in() ) {
		foreach ( array_keys( $endpoints ) as $route ) {
			if ( 0 === strpos( $route, '/wp/v2/users' ) ) {
				unset( $endpoints[ $route ] );
			}
		}
	}
	return $endpoints;
} );
remove_action( 'rest_api_init', 'wp_oembed_register_route' );
remove_action( 'template_redirect', 'rest_output_link_header', 11 );
remove_action( 'template_redirect', 'wp_shortlink_header', 11 );

// On activation: the pages, the home page and clean addresses.
add_action( 'after_switch_theme', function () {
	$pages = array(
		'home'      => 'Home',
		'servizi'   => 'Servizi',
		'metodo'    => 'Metodo',
		'chi-siamo' => 'Chi siamo',
		'contatti'  => 'Contatti',
		'privacy'   => 'Privacy Policy',
		'cookie'    => 'Cookie Policy',
	);
	foreach ( $pages as $slug => $title ) {
		if ( ! get_page_by_path( $slug ) ) {
			wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $slug, 'post_title' => $title ) );
		}
	}
	$home = get_page_by_path( 'home' );
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $home->ID );
	global $wp_rewrite;
	$wp_rewrite->set_permalink_structure( '/%postname%/' );
	flush_rewrite_rules();
} );

// The contact form.
add_action( 'rest_api_init', function () {
	register_rest_route( 'felicity/v1', '/contatto', array(
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
		'callback'            => 'fm_contatto',
	) );
} );

function fm_contatto( WP_REST_Request $r ) {
	// Filled only by bots: answer as if it had worked.
	if ( '' !== (string) $r->get_param( 'website' ) ) {
		return array( 'ok' => true );
	}
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$key = 'fm_c_' . md5( $ip );
	$n   = (int) get_transient( $key );
	if ( $n >= 5 ) {
		return new WP_REST_Response( array( 'ok' => false, 'error' => 'troppi' ), 429 );
	}
	$nome  = sanitize_text_field( (string) $r->get_param( 'nome' ) );
	$email = sanitize_email( (string) $r->get_param( 'email' ) );
	$tel   = sanitize_text_field( (string) $r->get_param( 'telefono' ) );
	$msg   = sanitize_textarea_field( (string) $r->get_param( 'messaggio' ) );
	if ( strlen( $nome ) < 2 || ! is_email( $email ) || strlen( $msg ) < 5 || ! $r->get_param( 'privacy' ) ) {
		return new WP_REST_Response( array( 'ok' => false, 'error' => 'dati' ), 400 );
	}
	$body = "Nome: $nome\nEmail: $email\nTelefono: " . ( $tel ? $tel : '-' ) . "\n\n$msg\n\n---\nConsenso privacy dato il " . wp_date( 'd/m/Y H:i' ) . " dal modulo su " . home_url( '/' ) . "\n";
	$sent = wp_mail( FM_MAIL, 'Richiesta dal sito · ' . $nome, $body, array( 'Reply-To: ' . $nome . ' <' . $email . '>' ) );
	if ( ! $sent ) {
		return new WP_REST_Response( array( 'ok' => false, 'error' => 'invio' ), 500 );
	}
	set_transient( $key, $n + 1, HOUR_IN_SECONDS );
	return array( 'ok' => true );
}
