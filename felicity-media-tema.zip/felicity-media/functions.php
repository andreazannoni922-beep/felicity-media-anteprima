<?php
defined( 'ABSPATH' ) || exit;

const FM_MAIL = 'info@felicitymedia.it';

// The pages carry their own markup and assets: WordPress adds nothing to them.
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );
remove_action( 'wp_head', 'rest_output_link_wp_head' );
remove_action( 'wp_head', 'feed_links', 2 );
remove_action( 'wp_head', 'feed_links_extra', 3 );
remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
add_filter( 'show_admin_bar', '__return_false' );
add_action( 'wp_enqueue_scripts', function () {
	foreach ( array( 'wp-block-library', 'global-styles', 'classic-theme-styles' ) as $h ) {
		wp_dequeue_style( $h );
	}
}, 100 );

// On activation: the pages, the home page and clean addresses.
add_action( 'after_switch_theme', function () {
	$pages = array(
		'home'      => 'Home',
		'servizi'   => 'Servizi',
		'metodo'    => 'Metodo',
		'chi-siamo' => 'Chi siamo',
		'contatti'  => 'Contatti',
		'privacy'   => 'Privacy Policy',
		'cookie'    => 'Cookie Policy',
	);
	foreach ( $pages as $slug => $title ) {
		if ( ! get_page_by_path( $slug ) ) {
			wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $slug, 'post_title' => $title ) );
		}
	}
	$home = get_page_by_path( 'home' );
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $home->ID );
	global $wp_rewrite;
	$wp_rewrite->set_permalink_structure( '/%postname%/' );
	flush_rewrite_rules();
} );

// The contact form.
add_action( 'rest_api_init', function () {
	register_rest_route( 'felicity/v1', '/contatto', array(
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
		'callback'            => 'fm_contatto',
	) );
} );

function fm_contatto( WP_REST_Request $r ) {
	// Filled only by bots: answer as if it had worked.
	if ( '' !== (string) $r->get_param( 'website' ) ) {
		return array( 'ok' => true );
	}
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$key = 'fm_c_' . md5( $ip );
	$n   = (int) get_transient( $key );
	if ( $n >= 5 ) {
		return new WP_REST_Response( array( 'ok' => false, 'error' => 'troppi' ), 429 );
	}
	$nome  = sanitize_text_field( (string) $r->get_param( 'nome' ) );
	$email = sanitize_email( (string) $r->get_param( 'email' ) );
	$tel   = sanitize_text_field( (string) $r->get_param( 'telefono' ) );
	$msg   = sanitize_textarea_field( (string) $r->get_param( 'messaggio' ) );
	if ( strlen( $nome ) < 2 || ! is_email( $email ) || strlen( $msg ) < 5 || ! $r->get_param( 'privacy' ) ) {
		return new WP_REST_Response( array( 'ok' => false, 'error' => 'dati' ), 400 );
	}
	$body = "Nome: $nome\nEmail: $email\nTelefono: " . ( $tel ? $tel : '-' ) . "\n\n$msg\n\n---\nConsenso privacy dato il " . wp_date( 'd/m/Y H:i' ) . " dal modulo su " . home_url( '/' ) . "\n";
	$sent = wp_mail( FM_MAIL, 'Richiesta dal sito · ' . $nome, $body, array( 'Reply-To: ' . $nome . ' <' . $email . '>' ) );
	if ( ! $sent ) {
		return new WP_REST_Response( array( 'ok' => false, 'error' => 'invio' ), 500 );
	}
	set_transient( $key, $n + 1, HOUR_IN_SECONDS );
	return array( 'ok' => true );
}
